-- phpMyAdmin SQL Dump
-- version 3.3.7deb7
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 28, 2013 at 02:33 PM
-- Server version: 5.1.66
-- PHP Version: 5.3.3-7+squeeze17

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `dev_ediface`
--

-- --------------------------------------------------------

--
-- Table structure for table `answers`
--

CREATE TABLE IF NOT EXISTS `answers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question_id` int(11) NOT NULL,
  `answer_text` text COLLATE utf8_unicode_ci NOT NULL,
  `answer_true` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `question_id` (`question_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=55 ;

--
-- Dumping data for table `answers`
--

INSERT INTO `answers` (`id`, `question_id`, `answer_text`, `answer_true`) VALUES
(13, 7, 'vcbvcbvc', 0),
(14, 7, 'bvcbvcvcbcvb', 1),
(15, 8, 'vcbvcbvcbvcbc', 1),
(16, 8, 'cvbvcbvcbvcbc', 0),
(24, 13, 'aaa1', 1),
(25, 13, 'aa2', 0),
(26, 14, 'bbb1', 1),
(27, 14, 'bbb2', 0),
(28, 15, 'ccc1', 0),
(29, 15, 'ccc2', 0),
(30, 15, 'ccc3', 1),
(31, 16, 'B - London', 0),
(32, 16, 'A - Paris', 0),
(33, 16, 'C - New Your', 0),
(34, 18, 'Paris?', 0),
(35, 18, 'London?', 0),
(36, 18, 'Munich?', 0),
(37, 19, 'Me?', 0),
(38, 19, 'Jim?', 0),
(39, 19, 'Steven?', 0),
(41, 22, 'London?', 0),
(42, 22, 'Paris', 0),
(43, 22, 'Madrid?', 0),
(44, 23, 'Tall?', 0),
(45, 23, 'Taller?', 0),
(46, 23, 'Tallest?', 0),
(47, 24, 'Paris', 0),
(48, 24, 'London', 0),
(49, 25, 'jon', 0),
(50, 25, 'albert', 1),
(51, 25, 'matt', 0),
(52, 26, 'Uk', 0),
(53, 26, 'France', 1),
(54, 26, 'Spain', 0);

-- --------------------------------------------------------

--
-- Table structure for table `assignments`
--

CREATE TABLE IF NOT EXISTS `assignments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `intro` text COLLATE utf8_unicode_ci NOT NULL,
  `grade_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `deadline_date` datetime NOT NULL,
  `assigned_to` int(11) NOT NULL,
  `depending_classes` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `active` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=21 ;

--
-- Dumping data for table `assignments`
--

INSERT INTO `assignments` (`id`, `title`, `intro`, `grade_type`, `deadline_date`, `assigned_to`, `depending_classes`, `active`) VALUES
(1, 'test title', 'test intro text', 'percentage', '2013-11-05 15:00:00', 2, 'a:1:{i:0;s:7:"class7a";}', 1),
(6, 'ttt', 'bbb', 'free_text', '2013-11-20 16:30:00', 5, 'a:1:{i:0;s:7:"class5b";}', 1),
(16, 'ttt', 'bbb', 'percentage', '2013-11-26 16:37:34', 5, 'b:0;', 1),
(17, 'test title', 'test intro text', 'percentage', '2013-11-25 21:19:34', 2, 'b:0;', 1),
(18, 'test title', 'test intro text', 'percentage', '2013-11-12 02:03:04', 2, 'a:2:{i:0;s:7:"class7a";i:1;s:7:"class5b";}', 1),
(19, 'ttt', 'bbb', '', '0000-00-00 00:00:00', 5, '', 0),
(20, 'Ibe''s Assignment', '', 'mark_out_of_10', '2013-11-30 00:56:00', 2, 'a:1:{i:0;s:7:"class7a";}', 1);

-- --------------------------------------------------------

--
-- Table structure for table `assignments_resourses`
--

CREATE TABLE IF NOT EXISTS `assignments_resourses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `resource_id` int(11) NOT NULL,
  `assignment_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `resource_id` (`resource_id`),
  KEY `assignment_id` (`assignment_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=14 ;

--
-- Dumping data for table `assignments_resourses`
--

INSERT INTO `assignments_resourses` (`id`, `resource_id`, `assignment_id`) VALUES
(2, 5, 6),
(3, 6, 6),
(8, 5, 16),
(9, 6, 16),
(10, 5, 19),
(11, 6, 19),
(12, 10, 20),
(13, 9, 20);

-- --------------------------------------------------------

--
-- Table structure for table `ci_sessions`
--

CREATE TABLE IF NOT EXISTS `ci_sessions` (
  `session_id` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `ip_address` varchar(45) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `user_agent` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`session_id`),
  KEY `last_activity_idx` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `ci_sessions`
--


-- --------------------------------------------------------

--
-- Table structure for table `content_page_slides`
--

CREATE TABLE IF NOT EXISTS `content_page_slides` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `text` text COLLATE utf8_unicode_ci NOT NULL,
  `template_id` int(11) NOT NULL,
  `interactive_lesson_id` int(11) NOT NULL,
  `active` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `interactive_lesson_id` (`interactive_lesson_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=17 ;

--
-- Dumping data for table `content_page_slides`
--

INSERT INTO `content_page_slides` (`id`, `title`, `text`, `template_id`, `interactive_lesson_id`, `active`) VALUES
(1, 'Content page 1', 'Content page 1', 1, 1, 1),
(3, 'Content page 3', 'Content page 3', 3, 1, 1),
(4, 'temp', 'temp', 0, 1, 0),
(6, '', '', 2, 2, 1),
(7, '', '', 3, 3, 1),
(9, '', '', 1, 4, 1),
(12, 'hh', 'hh', 2, 6, 1),
(13, 'temp', 'temp', 0, 7, 0),
(14, 'temp', 'temp', 0, 8, 0),
(16, 'temp', 'temp', 0, 9, 0);

-- --------------------------------------------------------

--
-- Table structure for table `cont_page_resourses`
--

CREATE TABLE IF NOT EXISTS `cont_page_resourses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `resource_id` int(11) NOT NULL,
  `cont_page_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cont_page_id` (`cont_page_id`),
  KEY `resource_id` (`resource_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=22 ;

--
-- Dumping data for table `cont_page_resourses`
--

INSERT INTO `cont_page_resourses` (`id`, `resource_id`, `cont_page_id`) VALUES
(9, 1, 1),
(10, 3, 3),
(11, 7, 4),
(12, 7, 6),
(13, 6, 7),
(14, 3, 9),
(19, 6, 14),
(21, 10, 16);

-- --------------------------------------------------------

--
-- Table structure for table `interactive_assessments_slides`
--

CREATE TABLE IF NOT EXISTS `interactive_assessments_slides` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `interactive_lesson_id` int(11) NOT NULL,
  `temp_data` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `interactive_lesson_id` (`interactive_lesson_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=15 ;

--
-- Dumping data for table `interactive_assessments_slides`
--

INSERT INTO `interactive_assessments_slides` (`id`, `interactive_lesson_id`, `temp_data`) VALUES
(1, 1, ''),
(5, 1, ''),
(6, 2, ''),
(7, 2, NULL),
(8, 3, ''),
(9, 6, ''),
(10, 6, 'a:1:{i:0;a:2:{s:20:"question_resource_id";s:0:"";s:13:"question_text";s:0:"";}}'),
(11, 6, ''),
(12, 6, ''),
(13, 7, 'a:1:{i:0;a:2:{s:20:"question_resource_id";s:2:"10";s:13:"question_text";s:0:"";}}'),
(14, 9, 'a:1:{i:0;a:2:{s:20:"question_resource_id";s:2:"10";s:13:"question_text";s:17:"spell this animal";}}');

-- --------------------------------------------------------

--
-- Table structure for table `interactive_lessons`
--

CREATE TABLE IF NOT EXISTS `interactive_lessons` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `publish` tinyint(1) NOT NULL,
  `lesson_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `lesson_id` (`lesson_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=10 ;

--
-- Dumping data for table `interactive_lessons`
--

INSERT INTO `interactive_lessons` (`id`, `publish`, `lesson_id`) VALUES
(1, 1, 57),
(2, 0, 66),
(3, 0, 67),
(4, 0, 68),
(5, 0, 70),
(6, 1, 72),
(7, 0, 78),
(8, 0, 79),
(9, 0, 81);

-- --------------------------------------------------------

--
-- Table structure for table `lessons`
--

CREATE TABLE IF NOT EXISTS `lessons` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `intro` text COLLATE utf8_unicode_ci NOT NULL,
  `objectives` text COLLATE utf8_unicode_ci NOT NULL,
  `module_id` int(11) NOT NULL,
  `published_lesson_plan` tinyint(1) DEFAULT NULL,
  `interactive_lesson_id` int(11) DEFAULT NULL,
  `active` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `module_id` (`module_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=82 ;

--
-- Dumping data for table `lessons`
--

INSERT INTO `lessons` (`id`, `title`, `intro`, `objectives`, `module_id`, `published_lesson_plan`, `interactive_lesson_id`, `active`) VALUES
(57, 'Algebra', 'What is algebra', '42', 1, 1, 1, 1),
(62, 'Trigonometry', 'Lesson 2', 'Lesson 2', 1, 1, NULL, 1),
(65, 'Geog', 'Geog', 'Geog', 6, 0, NULL, 1),
(66, 'Geog 2', 'Geog 2', 'Geog 2', 6, 0, 2, 1),
(67, 'Geology', 'Geology', 'Geology', 7, 0, 3, 1),
(68, 'Pete', 'Pete', 'Pete ddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd', 7, 0, 4, 1),
(70, 'glacial grography', 'intereesting', 'interesting facts', 9, 0, 5, 1),
(72, 'pete test', 'test', 'test', 10, 0, 6, 1),
(76, 'ngwr', 'ujnuioj', 'ouinjou[j', 11, 1, NULL, 1),
(78, 'bnuihuh', 'huiphup', 'uhpihui', 12, 1, 7, 1),
(79, 'hhy', 'bhhbiio', 'noiuinoni', 13, 0, 8, 1),
(81, 'australia', 'fwga', 'fdwdwvwvr', 14, 0, 9, 1);

-- --------------------------------------------------------

--
-- Table structure for table `lessons_resourses`
--

CREATE TABLE IF NOT EXISTS `lessons_resourses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `resource_id` int(11) NOT NULL,
  `lesson_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `resource_id` (`resource_id`),
  KEY `lesson_id` (`lesson_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=22 ;

--
-- Dumping data for table `lessons_resourses`
--

INSERT INTO `lessons_resourses` (`id`, `resource_id`, `lesson_id`) VALUES
(18, 6, 57),
(19, 6, 62),
(20, 2, 62),
(21, 6, 68);

-- --------------------------------------------------------

--
-- Table structure for table `modules`
--

CREATE TABLE IF NOT EXISTS `modules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `intro` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `objectives` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `publish` tinyint(1) NOT NULL,
  `active` tinyint(1) NOT NULL,
  `subject_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `subject_id` (`subject_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=16 ;

--
-- Dumping data for table `modules`
--

INSERT INTO `modules` (`id`, `name`, `intro`, `objectives`, `publish`, `active`, `subject_id`) VALUES
(1, 'Equations', 'Module 1', 'Module 1', 1, 1, 1),
(6, 'Geog', 'Geog', 'Geog', 0, 1, 8),
(7, 'Geog - Physical', 'Rocks', 'Rocks', 0, 1, 8),
(9, 'jon', 'test to show Jon', 'test to show Jon', 0, 1, 8),
(10, 'pete', 'test', 'test', 1, 1, 8),
(11, '', '', '', 1, 1, 2),
(12, 'uohbpou', 'huihu', 'bnuibni', 1, 1, 2),
(13, '43d', 'rc4c', 'crd4', 0, 1, 1),
(14, 'Animal spelling', 'fgcdssfwgsdenrswfwhrmv', '1) leaarm spelllim', 1, 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `modules_resourses`
--

CREATE TABLE IF NOT EXISTS `modules_resourses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `resource_id` int(11) NOT NULL,
  `module_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `resource_id` (`resource_id`),
  KEY `module_id` (`module_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `modules_resourses`
--

INSERT INTO `modules_resourses` (`id`, `resource_id`, `module_id`) VALUES
(1, 1, 1),
(2, 5, 1);

-- --------------------------------------------------------

--
-- Table structure for table `pictures`
--

CREATE TABLE IF NOT EXISTS `pictures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `object_id` int(11) NOT NULL,
  `object_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `hot` int(11) NOT NULL,
  `approved` int(11) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `pictures`
--


-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE IF NOT EXISTS `questions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `int_assessment_id` int(11) NOT NULL,
  `question_text` text COLLATE utf8_unicode_ci NOT NULL,
  `resource_id` int(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `int_assessment_id` (`int_assessment_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=27 ;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `int_assessment_id`, `question_text`, `resource_id`) VALUES
(7, 5, 'vcbvcbvc', NULL),
(8, 5, 'cvbvcbvcbcv', 9),
(9, 5, '', NULL),
(13, 1, 'aaa', 7),
(14, 1, 'bbb', NULL),
(15, 1, 'ccc', 10),
(16, 6, 'Where is the Eiffel Tower.', NULL),
(17, 6, '', NULL),
(18, 8, 'What is the capital of France?', NULL),
(19, 8, 'Who provided the x?', NULL),
(20, 8, '', NULL),
(22, 9, 'What is the capital of England?', NULL),
(23, 9, 'How tall is Jon?', NULL),
(24, 11, 'What is the capital of France?', NULL),
(25, 12, 'what is my name?', NULL),
(26, 12, 'where is everdon?', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `resourses`
--

CREATE TABLE IF NOT EXISTS `resourses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `teacher_id` int(11) NOT NULL,
  `resource_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `keywords` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `restriction_year` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=11 ;

--
-- Dumping data for table `resourses`
--

INSERT INTO `resourses` (`id`, `teacher_id`, `resource_name`, `name`, `keywords`, `description`, `restriction_year`) VALUES
(1, 1, 'bbe8199e9fc5337cfa318f8b75d0c3dc.jpg', 'resource 1', 'resource 1', 'resource 1', 'a:2:{i:0;s:1:"9";i:1;s:1:"8";}'),
(2, 1, '2e5d9fbdad532237db93f6a2cdfb896f.jpg', 'Resource 2', 'Resource 2', 'Resource 2', 'a:2:{i:0;s:1:"8";i:1;s:1:"7";}'),
(3, 1, '691d2b83f1d0e8d0a1b83c37b31219d0.jpg', 'Resource 3', 'Resource 3', 'Resource 3', 'a:1:{i:0;s:1:"9";}'),
(4, 1, '6a2b823a1d1de0cf0bd504f01b733671.jpg', 'Resource 4', 'Resource 4', 'Resource 4', 'a:1:{i:0;s:1:"9";}'),
(5, 1, '3df6a79f281881d4e6fdeb8f5938e302.jpg', 'Resource 5', 'Resource 5', 'Resource 5', 'a:2:{i:0;s:1:"8";i:1;s:1:"7";}'),
(6, 1, '469ecc1355a0bd356f1f61028d8b7336.jpg', 'Lesson resource', 'Lesson resource', 'Lesson resource', 'a:1:{i:0;s:1:"9";}'),
(7, 1, 'dbd632c86b8d1499b41185edf8983f5d.jpg', 'Qestion resource 1', 'Qestion resource 1', 'Qestion resource 1', 'a:1:{i:0;s:1:"9";}'),
(9, 1, '23fb5f0b1601f2a99117a671bf78bd77.jpg', 'Question resource 2', 'Question resource 2', 'Question resource 2', 'a:1:{i:0;s:1:"9";}'),
(10, 1, 'd1de19c09efe015423a515f39ed01711.jpg', 'Coala', 'Coala', 'Coala', 'a:1:{i:0;s:1:"9";}');

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE IF NOT EXISTS `subjects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=10 ;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`id`, `name`) VALUES
(1, 'Math'),
(2, 'English'),
(3, 'Music'),
(4, 'Art'),
(5, 'History'),
(6, 'French'),
(7, 'German'),
(8, 'Geography'),
(9, 'Chemistry');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `first_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ip` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_type` enum('teacher','student') COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=9 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `password`, `first_name`, `last_name`, `birthdate`, `timestamp`, `ip`, `user_type`) VALUES
(1, 'teacher@ediface.com', 'c4ca4238a0b923820dcc509a6f75849b', 'Peter', 'Jones', '2013-10-24', '2013-10-24 18:13:32', '95.111.90.14', 'teacher'),
(2, 'student@ediface.com', 'c4ca4238a0b923820dcc509a6f75849b', 'John', 'Lord', '2013-10-24', '2013-10-24 18:13:32', '95.111.90.14', 'student'),
(4, 'nathan@ediface.com', 'c4ca4238a0b923820dcc509a6f75849b', 'Nathan', 'Williams', '1995-05-16', '2013-11-07 15:24:18', '', 'student'),
(5, 'lucas@ediface.com', 'c4ca4238a0b923820dcc509a6f75849b', 'Lucas', 'Young', '2012-11-03', '2013-11-07 15:24:18', '', 'student'),
(6, 'ian@ediface.com', 'c4ca4238a0b923820dcc509a6f75849b', 'Ian', 'Carter', '2012-06-13', '2013-11-07 15:24:18', '', 'student'),
(7, 'alexander@ediface.com', 'c4ca4238a0b923820dcc509a6f75849b', 'Alexander', 'Reed', '2001-06-29', '2013-11-07 15:24:18', '', 'student'),
(8, 'sophia@ediface.com', 'c4ca4238a0b923820dcc509a6f75849b', 'Sophia', 'James', '2005-12-18', '2013-11-07 15:24:18', '', 'student');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `answers`
--
ALTER TABLE `answers`
  ADD CONSTRAINT `answers_ibfk_1` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `assignments_resourses`
--
ALTER TABLE `assignments_resourses`
  ADD CONSTRAINT `assignments_resourses_ibfk_2` FOREIGN KEY (`assignment_id`) REFERENCES `assignments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `assignments_resourses_ibfk_1` FOREIGN KEY (`resource_id`) REFERENCES `resourses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `content_page_slides`
--
ALTER TABLE `content_page_slides`
  ADD CONSTRAINT `content_page_slides_ibfk_1` FOREIGN KEY (`interactive_lesson_id`) REFERENCES `interactive_lessons` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cont_page_resourses`
--
ALTER TABLE `cont_page_resourses`
  ADD CONSTRAINT `cont_page_resourses_ibfk_1` FOREIGN KEY (`resource_id`) REFERENCES `resourses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cont_page_resourses_ibfk_2` FOREIGN KEY (`cont_page_id`) REFERENCES `content_page_slides` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `interactive_assessments_slides`
--
ALTER TABLE `interactive_assessments_slides`
  ADD CONSTRAINT `interactive_assessments_slides_ibfk_1` FOREIGN KEY (`interactive_lesson_id`) REFERENCES `interactive_lessons` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `interactive_lessons`
--
ALTER TABLE `interactive_lessons`
  ADD CONSTRAINT `interactive_lessons_ibfk_1` FOREIGN KEY (`lesson_id`) REFERENCES `lessons` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `lessons`
--
ALTER TABLE `lessons`
  ADD CONSTRAINT `lessons_ibfk_1` FOREIGN KEY (`module_id`) REFERENCES `modules` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `lessons_resourses`
--
ALTER TABLE `lessons_resourses`
  ADD CONSTRAINT `lessons_resourses_ibfk_2` FOREIGN KEY (`lesson_id`) REFERENCES `lessons` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `lessons_resourses_ibfk_1` FOREIGN KEY (`resource_id`) REFERENCES `resourses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `modules`
--
ALTER TABLE `modules`
  ADD CONSTRAINT `modules_ibfk_1` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `modules_resourses`
--
ALTER TABLE `modules_resourses`
  ADD CONSTRAINT `modules_resourses_ibfk_10` FOREIGN KEY (`module_id`) REFERENCES `modules` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `modules_resourses_ibfk_9` FOREIGN KEY (`resource_id`) REFERENCES `resourses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `questions`
--
ALTER TABLE `questions`
  ADD CONSTRAINT `questions_ibfk_1` FOREIGN KEY (`int_assessment_id`) REFERENCES `interactive_assessments_slides` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
